﻿Public Class frmMainMenu
  
   
    Private Sub RegisterVehicleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegisterVehicleToolStripMenuItem.Click
        If frmRegister Is Nothing OrElse frmRegister.IsDisposed Then
            Dim frmRegisterObject As New frmRegister
        End If
    End Sub

        frmRegister.MdiParent = Me
        frmRegister.Show()

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()

    End Sub
End Class