﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLogin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtDrivername = New System.Windows.Forms.TextBox()
        Me.lbldName = New System.Windows.Forms.Label()
        Me.txtDriverID = New System.Windows.Forms.TextBox()
        Me.lblId = New System.Windows.Forms.Label()
        Me.btnlogIn = New System.Windows.Forms.Button()
        Me.lblheading = New System.Windows.Forms.Label()
        Me.lblsignIn = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtDrivername
        '
        Me.txtDrivername.Location = New System.Drawing.Point(95, 54)
        Me.txtDrivername.Name = "txtDrivername"
        Me.txtDrivername.Size = New System.Drawing.Size(100, 20)
        Me.txtDrivername.TabIndex = 0
        '
        'lbldName
        '
        Me.lbldName.AutoSize = True
        Me.lbldName.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lbldName.Location = New System.Drawing.Point(8, 54)
        Me.lbldName.Name = "lbldName"
        Me.lbldName.Size = New System.Drawing.Size(66, 13)
        Me.lbldName.TabIndex = 1
        Me.lbldName.Text = "Driver Name"
        '
        'txtDriverID
        '
        Me.txtDriverID.Location = New System.Drawing.Point(95, 128)
        Me.txtDriverID.Name = "txtDriverID"
        Me.txtDriverID.Size = New System.Drawing.Size(100, 20)
        Me.txtDriverID.TabIndex = 2
        '
        'lblId
        '
        Me.lblId.AutoSize = True
        Me.lblId.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lblId.Location = New System.Drawing.Point(12, 131)
        Me.lblId.Name = "lblId"
        Me.lblId.Size = New System.Drawing.Size(49, 13)
        Me.lblId.TabIndex = 3
        Me.lblId.Text = "Driver ID"
        '
        'btnlogIn
        '
        Me.btnlogIn.ForeColor = System.Drawing.SystemColors.Highlight
        Me.btnlogIn.Location = New System.Drawing.Point(104, 154)
        Me.btnlogIn.Name = "btnlogIn"
        Me.btnlogIn.Size = New System.Drawing.Size(75, 23)
        Me.btnlogIn.TabIndex = 4
        Me.btnlogIn.Text = "Log In"
        Me.btnlogIn.UseVisualStyleBackColor = True
        '
        'lblheading
        '
        Me.lblheading.AutoSize = True
        Me.lblheading.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.lblheading.Location = New System.Drawing.Point(78, 9)
        Me.lblheading.Name = "lblheading"
        Me.lblheading.Size = New System.Drawing.Size(134, 13)
        Me.lblheading.TabIndex = 5
        Me.lblheading.Text = "SWIFT FLEET MANAGER"
        '
        'lblsignIn
        '
        Me.lblsignIn.AutoSize = True
        Me.lblsignIn.ForeColor = System.Drawing.SystemColors.Highlight
        Me.lblsignIn.Location = New System.Drawing.Point(120, 31)
        Me.lblsignIn.Name = "lblsignIn"
        Me.lblsignIn.Size = New System.Drawing.Size(40, 13)
        Me.lblsignIn.TabIndex = 6
        Me.lblsignIn.Text = "Sign In"
        '
        'btnCancel
        '
        Me.btnCancel.ForeColor = System.Drawing.Color.Red
        Me.btnCancel.Location = New System.Drawing.Point(104, 217)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 7
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'frmLogin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.lblsignIn)
        Me.Controls.Add(Me.lblheading)
        Me.Controls.Add(Me.btnlogIn)
        Me.Controls.Add(Me.lblId)
        Me.Controls.Add(Me.txtDriverID)
        Me.Controls.Add(Me.lbldName)
        Me.Controls.Add(Me.txtDrivername)
        Me.Name = "frmLogin"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtDrivername As System.Windows.Forms.TextBox
    Friend WithEvents lbldName As System.Windows.Forms.Label
    Friend WithEvents txtDriverID As System.Windows.Forms.TextBox
    Friend WithEvents lblId As System.Windows.Forms.Label
    Friend WithEvents btnlogIn As System.Windows.Forms.Button
    Friend WithEvents lblheading As System.Windows.Forms.Label
    Friend WithEvents lblsignIn As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button

End Class
